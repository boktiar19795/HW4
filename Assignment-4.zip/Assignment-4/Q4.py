# Custom implementation of list creation
def link(node, next_link):
    return [node, next_link]

# Custom implementation of checking if a linked list is sorted
def is_sorted(lnk):
    while lnk[1]:
        if lnk[0] > lnk[1][0]:
            return False
        lnk = lnk[1]
    return True

def create_linked_list():
    nodes = input("Enter a list of nodes separated by spaces: ").split()
    lnk = []
    for node in reversed(nodes):
        lnk = link_custom(int_or_float(node), lnk)
    return lnk

def int_or_float(s):
    try:
        return int(s)
    except ValueError:
        return float(s)

def link_custom(node, next_link):
    return [node, next_link]

def is_sorted_custom(lnk):
    while lnk[1]:
        if lnk[0] > lnk[1][0]:
            return False
        lnk = lnk[1]
    return True

def main():
    lnk1 = create_linked_list()
    print("Is lnk1 sorted?", is_sorted_custom(lnk1))

    lnk2 = create_linked_list()
    print("Is lnk2 sorted?", is_sorted_custom(lnk2))

    lnk3 = create_linked_list()
    print("Is lnk3 sorted?", is_sorted_custom(lnk3))

if __name__ == "__main__":
    main()
