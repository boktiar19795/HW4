class LinkedListNode:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next_node = next_node


def cntn_link(s, elm):
    if s is None:
        return False
    elif s.value == elm:
        return True

    return cntn_link(s.next_node, elm)


def create_linked_list(values):
    if not values:
        return None
    else:
        return LinkedListNode(values[0], create_linked_list(values[1:]))


# Manual user input for creating linked list
def get_user_input():
    node_vals = input("Enter node values separated by commas: ")
    nodes = node_vals.split(',')
    return create_linked_list(nodes)


def main():
    user_linked_list = get_user_input()

    element = input("Enter element to search for: ")

    result = cntn_link(user_linked_list, element)
    if result:
        print(f"True: {element} is present in the linked list.")
    else:
        print(f"False: {element} is not present in the linked list.")


if __name__ == "__main__":
    main()
