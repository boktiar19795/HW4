def create_linked_list():
    nodes = input("Enter a list of nodes separated by spaces: ").split()
    lnk = []
    for node in reversed(nodes):
        lnk = link(node, lnk)
    return lnk

def link(node, next_link):
    return [node, next_link]

def change(lnk, u, v):
    new_link = []
    helper = []
    while lnk:
        if lnk[0] == u:
            helper.append(v)
        else:
            helper.append(lnk[0])
        lnk = lnk[1]

    index = len(helper) - 1
    counter = index
    while counter >= 0:
        new_link = link(helper[counter], new_link)
        counter -= 1
    return new_link

def main():
    lnk = create_linked_list()

    u = input("Enter u: ")
    v = input("Enter v: ")

    new_lnk = change(lnk, u, v)
    print("New linked list after change:", new_lnk)

if __name__ == "__main__":
    main()
