def apnd(lnk, m):
    new_link = []
    helper = []

    # Traverse the original linked list
    while lnk:
        helper.append(lnk[0])
        lnk = lnk[1]

    # Append the new element to the helper list
    helper.append(m)

    index = len(helper) - 1
    while index >= 0:
        new_link = link(helper[index], new_link)
        index -= 1
    return new_link

def link(node, next_link):
    return [node, next_link]

def first(lst):
    return lst[0]

def rest(lst):
    return lst[1]

def create_linked_list():
    nodes = input("Enter a list of nodes separated by spaces: ").split()
    lnk = []
    for node in nodes:
        lnk = link(node, lnk)
    return lnk

def main():
    l = create_linked_list()
    m = input("Enter the element to append: ")
    n = apnd(l, m)

    result = first(rest(rest(rest(n))))
    print("Result:", result)

if __name__ == "__main__":
    main()
