def insrt(l, elm, ind):
    new_link = []
    index = 0

    while l and index < ind:
        new_link = link(l[0], new_link)
        l = l[1]
        index += 1

    new_link = link(elm, new_link)

    while l:
        new_link = link(l[0], new_link)
        l = l[1]

    return reverse_list(new_link)

def link(node, next_link):
    return [node, next_link]

def reverse_list(lst):
    new_lst = []
    while lst:
        new_lst = link(lst[0], new_lst)
        lst = lst[1]
    return new_lst

def create_linked_list():
    nodes = input("Enter a list of nodes separated by spaces: ").split()
    lnk = []
    for node in nodes:
        lnk = link(node, lnk)
    return reverse_list(lnk)

def main():
    l = create_linked_list()
    elm = input("Enter the element to insert: ")
    ind = int(input("Enter the index to insert at: "))
    n = insrt(l, elm, ind)
    print(n)

if __name__ == "__main__":
    main()
