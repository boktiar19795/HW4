def sum_lnk(lnk, g):
    new_list = []
    result = 0
    while lnk:
        new_list.append(lnk[0])
        lnk = lnk[1]
    for i in new_list:
        result += g(i)
    return result

def link(node, next_link):
    return [node, next_link]

def create_linked_list():
    nodes = input("Enter a list of nodes separated by spaces: ").split()
    lnk = []
    for node in reversed(nodes):
        lnk = link(int(node), lnk)
    return lnk

def sqr(x):
    return x * x

def dbl(y):
    return 2 * y

def main():
    lnk1 = create_linked_list()
    print("Result for lnk1:", sum_lnk(lnk1, sqr))

    lnk2 = create_linked_list()
    print("Result for lnk2:", sum_lnk(lnk2, dbl))

if __name__ == "__main__":
    main()
