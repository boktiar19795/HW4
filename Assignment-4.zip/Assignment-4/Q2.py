class Link:
    def __init__(self, value, rest=None):
        self.value = value
        self.rest = rest

    def __repr__(self):
        if self.rest is None:
            return f"link({repr(self.value)}, empty)"
        return f"link({repr(self.value)}, {repr(self.rest)})"


def prnt_lnk(s):
    """
    >>> prnt_lnk(link(1, link(2, link(3, link(4, empty)))))
    <1 2 3 4>
    """
    if s is None:
        print("<>")
    else:
        elements = []
        while s is not None:
            elements.append(str(s.value))
            s = s.rest
        print("<" + " ".join(elements) + ">")


def create_linked_list():
    elements = input("Enter space-separated elements for the linked list: ").split()
    linked_list = None
    for element in reversed(elements):
        linked_list = Link(element, linked_list)
    return linked_list


# Example usage
if __name__ == "__main__":
    empty = None

    def link(value, rest=empty):
        return Link(value, rest)

    user_linked_list = create_linked_list()
    prnt_lnk(user_linked_list)
