class Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next_node = next_node

def rvrs_lnk(node):
    reversed_list = None
    while node:
        reversed_list = link(node.value, reversed_list)
        node = node.next_node
    return reversed_list

def link(node, next_node):
    return [node, next_node]

def display_linked_list(linked_list):
    if linked_list is None:
        return "[]"
    
    return "[" + str(linked_list[0]) + ", " + display_linked_list(linked_list[1]) + "]"

def create_linked_list():
    values = input("Enter space-separated values for the linked list: ").split()
    linked_list = None
    
    for val in reversed(values):
        linked_list = Node(val, linked_list)
    
    return linked_list

if __name__ == "__main__":
    user_linked_list = create_linked_list()
    reversed_linked_list = rvrs_lnk(user_linked_list)
    
    print("Reversed Linked List:", display_linked_list(reversed_linked_list))
